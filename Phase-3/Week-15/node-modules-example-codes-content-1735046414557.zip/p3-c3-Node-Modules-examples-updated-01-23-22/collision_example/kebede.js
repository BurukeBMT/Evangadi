var AAvar3 = 3;

function AAsomeFunction() {
  var a = 9;
  console.log(AAvar3);
}

console.log("Olla");
