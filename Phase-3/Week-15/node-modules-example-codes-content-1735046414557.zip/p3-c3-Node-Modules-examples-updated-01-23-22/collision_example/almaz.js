// IIFE way
(function require() {
  var AAvar5 = 5;

  function AAsomeFunction() {
    var a = 9;
    console.log(AAvar5);
  }

  return AAsomeFunction();
})();
