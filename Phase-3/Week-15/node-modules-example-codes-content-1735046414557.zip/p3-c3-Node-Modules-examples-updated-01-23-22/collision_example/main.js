console.log(window);
// AAsomeFunction();
// // AAalmaz();
