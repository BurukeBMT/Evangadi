const abdu = require("./abebe");
const kebe = require("./kebede");

// ES6
import AAvar1, { AAsomeFunction, sum } from "./abebe.js";

// const kebe = require("./kebede");

// console.log(global);
// console.log("Test");
// console.log(__filename);
// console.log(__dirname);

// console.log(abebe);

abe.AAsomeFunction();
kebe.AAsomeFunction();

abe.sum(9, 10);
