var AAvar3 = 3;

function AAsomeFunction() {
  console.log(AAvar3);
}

exports.AAsomeFunction = AAsomeFunction;
// exports.AAvar3 = AAvar3;
