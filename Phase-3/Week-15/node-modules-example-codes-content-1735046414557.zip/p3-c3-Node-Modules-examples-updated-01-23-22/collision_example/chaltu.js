var AAchaltu = function () {
  var AAvar6 = 6;

  function AAsomeFunction() {
    console.log(AAvar6);
  }

  return AAsomeFunction();
};
