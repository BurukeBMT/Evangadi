var AAvar1 = 1;

function AAsomeFunction() {
  var AAsecondVar = 2;
  console.log(AAvar1);
}

// AAsomeFunction();

// console.log(Object)
