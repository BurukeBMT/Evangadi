// // Arithmetic operators
// var a, b, c, d, e;
// a = 2876;
// b = 37654;
// c = a + b;
// d = a * b;
// // console.log(d);
// e = (a + b) * (c / d);
// console.log(e);

// // String Operator (Concatenation)
// var a = "";
// var b = " Another Text";
// var c = a + b;
// console.log(c);

// // Comparison Operators
// var a = "A";
// var b = 65;
// console.log(a == b);

// ** Why is 5 less than A

// // Logical Operators
// console.log(1 == 1 || 2 == 2 || 3 == 7);

// // Weak Typing
// var a = 5;
// var b = "T";
// // a = true;
// console.log(a);

// var c = a + b;
// console.log(c);

// if (1 == 1) {
//   console.log("Working");
// }

// // Array
// // Declaring empty array
// let exampleArray = [];
// // Adding values to an Array
// exampleArray = ["white", "black", "orange"];
// // Accessing array values with index
// console.log(exampleArray);
// console.log(exampleArray[1]);

// // Declaring/defining  a function
// function onn(id) {
//   console.log("We are on .. ");
//   console.log("The id is " + id);
// }
// // Calling/using a function
// onn(345698);
// onn(564321);

// // Functions with arguments
// function myFunctionNameWithArgument(a) {
//   console.log(a);
// }

// // myFunctionNameWithArgument("Abebe beso bela");
// function myAdditionCalculator(a, b) {
//   var c;
//   c = a + b;
//   console.log(c);
// }
// myAdditionCalculator(45, 99);

// // Functions that return a value
// function myAdditionCalculator2(a, b) {
//   var c;
//   c = a + b;
//   var d = (a + b) / 2;
//   return [c, d];
// }
// // How to use it
// var a = myAdditionCalculator2(45, 99);
// console.log(a);
// // My average calculator
// function myAverageCalculator(a, b) {
//   var c = (a + b) / 2;
//   return c;
// }
// var ave = myAverageCalculator(40, 60);
// console.log(ave);
// // Another way of writing the same function
// function myAverageCalculator2(a, b) {
//   var c = myAdditionCalculator2(a, b) / 2;
//   return c;
// }
// var ave = myAverageCalculator2(40, 60);
// console.log(ave);

// Variable Scoping (var, let & const)
